//
//  MovieGridCell.swift
//  Moviebuster
//
//  Created by Rojin Prajapati on 9/27/21.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
    
}
